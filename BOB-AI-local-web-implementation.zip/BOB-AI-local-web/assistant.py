"""BOB-AI desktop voice assistant; AI answers use the local Ollama service."""
import os
import tempfile
import threading
import time

import sounddevice as sd
import scipy.io.wavfile as wav
import speech_recognition as sr
import pyttsx3

from commands import CommandHandler
from core.brain import ask_local_ai

WAKE_WORDS = ["hey bob", "bob", "hey jarvis", "jarvis", "yo bob", "ok bob",
              "jai balayya", "jai babu"]
SLEEP_WORDS = ["sleep", "bye", "goodbye", "go to sleep", "stop listening"]
SAMPLE_RATE = 16000

class Assistant:
    def __init__(self, gui_callback=None):
        self.gui_callback = gui_callback
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True
        self.engine = pyttsx3.init()
        self.engine.setProperty("rate", 168)
        self.engine.setProperty("volume", 1.0)
        voices = self.engine.getProperty("voices")
        if voices:
            self.engine.setProperty("voice", voices[0].id)
        self.cmd = CommandHandler(
            speak_fn=self.speak,
            listen_raw_fn=self.listen_raw,
            gui_fn=self.gui_callback
        )
        self._log("BOB-AI initialized with local Ollama brain!", "system")

    def _log(self, text, role="info"):
        print(f"[{role.upper()}] {text}")
        if self.gui_callback:
            self.gui_callback(text, role)

    def speak(self, text):
        self._log(text, "bob")
        try:
            self.engine.say(text)
            self.engine.runAndWait()
        except Exception as exc:
            print(f"[TTS ERROR] {exc}")

    def speak_async(self, text):
        threading.Thread(target=self.speak, args=(text,), daemon=True).start()

    def _record(self, duration=5):
        self._log("Listening...", "listening")
        audio = sd.rec(int(duration * SAMPLE_RATE), samplerate=SAMPLE_RATE,
                       channels=1, dtype="int16")
        sd.wait()
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp.close()
        wav.write(tmp.name, SAMPLE_RATE, audio)
        return tmp.name

    def _transcribe(self, duration):
        path = self._record(duration)
        try:
            with sr.AudioFile(path) as source:
                audio = self.recognizer.record(source)
            text = self.recognizer.recognize_google(audio).lower().strip()
            self._log(f"Heard: {text}", "user")
            return text
        finally:
            try:
                os.remove(path)
            except OSError:
                pass

    def listen(self, duration=5):
        try:
            return self._transcribe(duration)
        except sr.UnknownValueError:
            return ""
        except Exception as exc:
            self._log(f"Listen error: {exc}", "error")
            return ""

    def listen_raw(self, duration=6):
        try:
            return self._transcribe(duration)
        except sr.UnknownValueError:
            self._log("Didn't catch that", "error")
            return ""
        except Exception as exc:
            self._log(f"Raw listen error: {exc}", "error")
            return ""

    def wait_for_wake_word(self):
        self._log("Waiting for 'Hey Bob'...", "idle")
        while True:
            heard = self.listen(duration=3)
            if heard and any(word in heard for word in WAKE_WORDS):
                self._log("Wake word detected!", "system")
                return True

    def ask_gemini(self, query):
        """Compatibility name retained; this now calls local Ollama, not Gemini."""
        try:
            self._log("Thinking with local AI...", "processing")
            reply = ask_local_ai([{"role": "user", "content": query}])
            reply = " ".join(reply.strip().split())
            return reply[:397] + "..." if len(reply) > 400 else reply
        except Exception as exc:
            self._log(f"Local AI error: {exc}", "error")
            return "My local brain is offline. Please check that Ollama is running."

    def process_command(self, command):
        self._log(f"Processing: {command}", "processing")
        if not self.cmd.handle(command):
            self.speak(self.ask_gemini(command))

    def run(self):
        time.sleep(2)
        self.speak("BOB online. Say Hey Bob whenever you need me.")
        while True:
            try:
                self.wait_for_wake_word()
                self.speak("Yeah, what's up?")
                misses = 0
                while True:
                    command = self.listen(duration=6)
                    if command and any(word in command for word in SLEEP_WORDS):
                        self.speak("Alright, going quiet. Holler if you need me.")
                        break
                    if not command:
                        misses += 1
                        if misses >= 3:
                            self.speak("Didn't hear you, going back to sleep.")
                            break
                        continue
                    misses = 0
                    self.process_command(command)
                    self._log("Ready for next command...", "idle")
            except KeyboardInterrupt:
                self.speak("Later bro!")
                break
            except Exception as exc:
                self._log(f"Error: {exc}", "error")
                time.sleep(1)
