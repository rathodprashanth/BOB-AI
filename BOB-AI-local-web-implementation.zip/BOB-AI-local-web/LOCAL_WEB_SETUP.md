# BOB AI — Local web interface

This adds a separate browser interface. It does **not** replace the desktop assistant.
Both interfaces use the same Ollama model running on this computer.

## 1. Install and start Ollama

Install Ollama for Windows from https://ollama.com/download

Open PowerShell and run:

```powershell
ollama pull llama3.2
ollama serve
```

If Ollama is already running as a Windows background app, `ollama serve` may say the port is in use; that is okay. Check with:

```powershell
ollama list
```

You should see `llama3.2`.

## 2. Install Python dependencies

From the BOB-AI repository folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate.bat
```

## 3. Start the web interface

```powershell
py -m uvicorn web_app:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 in your browser.

**Keep the server bound to `127.0.0.1`.** This is intentionally local-only: it does not publish your PC or Ollama to the internet. Do not change the host to `0.0.0.0` or expose port 8000/11434 on your router.

Stop the web server with Ctrl+C.

## 4. Start the desktop assistant separately

In a second terminal, from the same folder:

```powershell
py main.py
```

The desktop assistant requires a working microphone, audio devices and desktop environment. The web app does not require those desktop dependencies to answer typed chat messages.

## 5. Model selection

The default model is `llama3.2`. To use another model:

```powershell
$env:OLLAMA_MODEL="qwen2.5:7b"
py -m uvicorn web_app:app --host 127.0.0.1 --port 8000
```

Pull that model first with `ollama pull qwen2.5:7b`.

## Notes and limitations

- The browser UI currently provides local AI chat and browser speech-to-text where supported.
- Desktop actions such as opening Notepad, typing into Windows, screenshots, local file access and the desktop microphone remain in `main.py` and are **not** exposed as web commands.
- The browser conversation is held in page memory; refreshing clears the current conversation.
- The server calls Ollama at `http://127.0.0.1:11434` by default.
- This is a local development web app, not a public hosted website. A public site cannot directly reach an Ollama server bound to your private PC without a separately designed, authenticated secure tunnel or VPN.
- Do not commit API keys, Gmail app passwords, WhatsApp session folders or `.env` files.

## Security action required

The current repository's earlier `commands.py` version contained a Gmail App Password in plaintext. Revoke that password in your Google Account immediately and create a replacement only if needed. The updated `commands.py` should read `BOB_GMAIL_ADDRESS` and `BOB_GMAIL_APP_PASSWORD` from environment variables. Removing a secret from the latest file does not erase it from Git history.
