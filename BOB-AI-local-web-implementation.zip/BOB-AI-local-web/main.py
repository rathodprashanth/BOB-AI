"""
BOB-AI desktop assistant entry point.
Run with: python main.py
Start the separate web UI with:
python -m uvicorn web_app:app --host 127.0.0.1 --port 8000
"""
import threading
import tkinter as tk
from assistant import Assistant
from gui import AssistantGUI

def main():
    root = tk.Tk()
    gui = AssistantGUI(root)
    bob = Assistant(gui_callback=gui.update)
    threading.Thread(target=bob.run, daemon=True).start()
    root.mainloop()

if __name__ == "__main__":
    main()
