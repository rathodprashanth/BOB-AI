"""Local-only BOB AI web interface API. Bind to 127.0.0.1, not a public interface."""
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
import httpx

from core.brain import ask_local_ai, ollama_status

BASE_DIR = Path(__file__).resolve().parent
app = FastAPI(title="BOB AI Local Web", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=BASE_DIR / "web" / "static"), name="static")

class ChatRequest(BaseModel):
    messages: list[dict] = Field(min_length=1, max_length=20)

@app.get("/", response_class=HTMLResponse)
async def home():
    return (BASE_DIR / "web" / "templates" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
async def health():
    return ollama_status()

@app.post("/api/chat")
async def chat(payload: ChatRequest):
    # Validate roles and cap content before forwarding to local Ollama.
    cleaned = []
    for item in payload.messages:
        role = item.get("role")
        content = str(item.get("content", "")).strip()
        if role not in ("user", "assistant") or not content:
            continue
        cleaned.append({"role": role, "content": content[:8000]})
    if not cleaned or cleaned[-1]["role"] != "user":
        raise HTTPException(status_code=400, detail="Send a user message to BOB.")
    try:
        answer = ask_local_ai(cleaned)
        return {"reply": answer, "model": ollama_status().get("model")}
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Ollama is not running. Start Ollama and try again.")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Ollama returned HTTP {exc.response.status_code}.")
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="The local model took too long to respond.")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
