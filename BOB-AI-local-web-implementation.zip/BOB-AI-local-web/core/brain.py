"""Shared local Ollama client used by BOB's desktop and web interfaces."""
import os
import httpx

OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
SYSTEM_PROMPT = """You are BOB, a sharp, witty and helpful personal assistant built by Ganesh.
Be friendly and natural, like a smart friend. Use occasional light humor.
For technical or serious topics, prioritize accuracy. Do not claim to control
the user's computer unless a local desktop command actually did so."""

def ask_local_ai(messages, timeout=None):
    """Send chat messages to the local Ollama server and return its reply."""
    payload_messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for item in messages[-20:]:
        role = item.get("role")
        content = str(item.get("content", "")).strip()
        if role in ("user", "assistant") and content:
            payload_messages.append({"role": role, "content": content[:8000]})
    if len(payload_messages) == 1:
        raise ValueError("No chat message was provided.")
    response = httpx.post(
        f"{OLLAMA_URL}/api/chat",
        json={"model": OLLAMA_MODEL, "messages": payload_messages, "stream": False},
        timeout=timeout or httpx.Timeout(120.0, connect=5.0)
    )
    response.raise_for_status()
    data = response.json()
    answer = data.get("message", {}).get("content", "").strip()
    if not answer:
        raise RuntimeError("Ollama returned an empty response.")
    return answer

def ollama_status():
    try:
        response = httpx.get(f"{OLLAMA_URL}/api/tags", timeout=3.0)
        response.raise_for_status()
        models = [m.get("name", "") for m in response.json().get("models", [])]
        return {"ok": True, "model": OLLAMA_MODEL, "available_models": models}
    except Exception as exc:
        return {"ok": False, "model": OLLAMA_MODEL, "error": str(exc)}
